const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState, useEffect } from "react";

import { Plus, Pencil, Trash2, ArrowLeft, Save, X, Stethoscope, AlertCircle } from "lucide-react";
import ConditionForm from "@/components/conditions/ConditionForm";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";

const severityStyles = {
  mild: "bg-emerald-100 text-emerald-700 border-emerald-200",
  moderate: "bg-amber-100 text-amber-700 border-amber-200",
  severe: "bg-red-100 text-red-700 border-red-200",
};

export default function ConditionsManager() {
  const [conditions, setConditions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState(null);
  const [creating, setCreating] = useState(false);

  const load = async () => {
    try {
      const data = await db.entities.BackPainCondition.list();
      setConditions(data);
    } catch {
      setConditions([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
  }, []);

  const handleDelete = async (id, name) => {
    if (!window.confirm(`Delete "${name}"? This will remove it from the chatbot's database.`)) return;
    await db.entities.BackPainCondition.delete(id);
    load();
  };

  const handleSave = async (data) => {
    if (editing) {
      await db.entities.BackPainCondition.update(editing.id, data);
    } else {
      await db.entities.BackPainCondition.create(data);
    }
    setEditing(null);
    setCreating(false);
    load();
  };

  if (creating || editing) {
    return (
      <div className="min-h-screen bg-slate-50">
        <div className="max-w-3xl mx-auto px-4 py-6">
          <div className="flex items-center justify-between mb-6">
            <h1 className="text-xl font-semibold text-slate-900">
              {editing ? "Edit Condition" : "Add New Condition"}
            </h1>
            <Button variant="ghost" onClick={() => { setEditing(null); setCreating(false); }}>
              <X className="w-4 h-4 mr-1" /> Cancel
            </Button>
          </div>
          <ConditionForm
            initial={editing}
            onSave={handleSave}
          />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50">
      <header className="bg-white border-b border-slate-200 sticky top-0 z-10">
        <div className="max-w-5xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <a href="/" className="flex items-center gap-2 text-slate-500 hover:text-slate-900 transition-colors">
              <ArrowLeft className="w-5 h-5" />
            </a>
            <div>
              <h1 className="text-lg font-semibold text-slate-900">Conditions Database</h1>
              <p className="text-xs text-slate-500">
                {conditions.length} condition{conditions.length !== 1 ? "s" : ""} — this is what the chatbot uses
              </p>
            </div>
          </div>
          <Button onClick={() => setCreating(true)} className="bg-gradient-to-br from-blue-500 to-teal-500 hover:from-blue-600 hover:to-teal-600">
            <Plus className="w-4 h-4 mr-1" /> Add Condition
          </Button>
        </div>
      </header>

      <div className="max-w-5xl mx-auto px-4 py-6">
        {loading ? (
          <div className="flex justify-center py-20">
            <div className="w-8 h-8 border-4 border-slate-200 border-t-slate-700 rounded-full animate-spin" />
          </div>
        ) : conditions.length === 0 ? (
          <Card className="p-12 text-center">
            <AlertCircle className="w-10 h-10 text-slate-300 mx-auto mb-3" />
            <p className="text-slate-500">No conditions yet. Add your first one to power the chatbot.</p>
          </Card>
        ) : (
          <div className="grid gap-3">
            {conditions.map((cond) => (
              <Card key={cond.id} className="p-4 hover:shadow-md transition-shadow">
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap mb-1">
                      <h3 className="font-semibold text-slate-900">{cond.name}</h3>
                      {cond.severity && (
                        <span className={`text-xs font-medium px-2 py-0.5 rounded-full border ${severityStyles[cond.severity]}`}>
                          {cond.severity}
                        </span>
                      )}
                      {cond.see_doctor && (
                        <span className="inline-flex items-center gap-1 text-xs font-medium px-2 py-0.5 rounded-full border bg-blue-50 text-blue-700 border-blue-200">
                          <Stethoscope className="w-3 h-3" /> Doctor advised
                        </span>
                      )}
                    </div>
                    <p className="text-sm text-slate-600 line-clamp-2 mb-2">{cond.description}</p>
                    {cond.symptoms?.length > 0 && (
                      <div className="flex flex-wrap gap-1.5">
                        {cond.symptoms.slice(0, 4).map((s, idx) => (
                          <span key={idx} className="text-xs bg-slate-100 text-slate-600 px-2 py-0.5 rounded-md">
                            {s}
                          </span>
                        ))}
                        {cond.symptoms.length > 4 && (
                          <span className="text-xs text-slate-400 px-2 py-0.5">
                            +{cond.symptoms.length - 4} more
                          </span>
                        )}
                      </div>
                    )}
                  </div>
                  <div className="flex gap-2 flex-shrink-0">
                    <Button variant="outline" size="icon" onClick={() => setEditing(cond)}>
                      <Pencil className="w-4 h-4" />
                    </Button>
                    <Button variant="outline" size="icon" onClick={() => handleDelete(cond.id, cond.name)} className="text-red-600 hover:text-red-700 hover:border-red-300">
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}