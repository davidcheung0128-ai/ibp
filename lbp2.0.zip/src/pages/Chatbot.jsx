const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState, useRef, useEffect } from "react";
import { Send, Bot, User, AlertCircle, Stethoscope, Activity, ShieldAlert, Database } from "lucide-react";

import MessageBubble from "@/components/chat/MessageBubble";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";

const SUGGESTED_PROMPTS = [
  "I have a sharp pain in my lower back when I bend forward",
  "My lower back aches after sitting all day at work",
  "Pain radiating from my lower back down to my leg",
  "I lifted something heavy and now my back hurts",
];

export default function Chatbot() {
  const [messages, setMessages] = useState([
    {
      role: "assistant",
      content:
        "Hello! I'm here to help you understand your lower back pain. Describe your symptoms — when they started, how they feel, and what triggers them. I'll analyze your description and share relevant information from our database.\n\n⚠️ **Important:** This tool provides educational information only and is **not a medical diagnosis**. Always consult a healthcare professional for proper evaluation and treatment.",
    },
  ]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [conditions, setConditions] = useState([]);
  const scrollRef = useRef(null);

  useEffect(() => {
    db.entities.BackPainCondition.list().then(setConditions).catch(() => {});
  }, []);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isLoading]);

  const handleSend = async (textToSend) => {
    const text = (textToSend ?? input).trim();
    if (!text || isLoading) return;

    const userMsg = { role: "user", content: text };
    setMessages((prev) => [...prev, userMsg]);
    setInput("");
    setIsLoading(true);

    try {
      const conditionsContext = conditions
        .map(
          (c) =>
            `Condition: ${c.name}\nDescription: ${c.description}\nSymptoms: ${c.symptoms?.join(", ")}\nCommon Causes: ${c.common_causes?.join(", ") || "N/A"}\nSeverity: ${c.severity}\nSelf-Care: ${c.self_care?.join(", ") || "N/A"}\nDoctor Recommended: ${c.see_doctor ? "Yes" : "No"}${c.doctor_reason ? ` — ${c.doctor_reason}` : ""}`
        )
        .join("\n\n---\n\n");

      const prompt = `You are a knowledgeable assistant helping patients understand lower back pain. A patient has described their symptoms below.

PATIENT DESCRIPTION:
"${text}"

CONDITIONS DATABASE (use this as your reference for matching and information):
${conditionsContext}

Based on the patient's description, analyze which conditions from the database might be relevant. Provide:
1. A brief, empathetic acknowledgment of their concern
2. Which condition(s) from the database seem most relevant and why
3. A clear explanation of what might be happening
4. Self-care suggestions from the database if applicable
5. A clear recommendation on whether they should see a doctor, and why

Keep the tone supportive, clear, and non-technical. Use bullet points where helpful. Always end with a reminder that this is educational information and not a medical diagnosis.

If the patient describes symptoms not covered by the database, acknowledge this and suggest they consult a doctor for a proper evaluation.`;

      const response = await db.integrations.Core.InvokeLLM({
        prompt,
        response_json_schema: {
          type: "object",
          properties: {
            response: { type: "string" },
            matched_conditions: {
              type: "array",
              items: { type: "string" },
            },
            recommend_doctor: { type: "boolean" },
            urgency: { type: "string", enum: ["low", "moderate", "high"] },
          },
        },
      });

      const assistantContent = response.response || response;
      setMessages((prev) => [
        ...prev,
        {
          role: "assistant",
          content:
            typeof assistantContent === "string"
              ? assistantContent
              : JSON.stringify(assistantContent, null, 2),
          matchedConditions: response.matched_conditions || [],
          recommendDoctor: response.recommend_doctor,
          urgency: response.urgency,
        },
      ]);
    } catch (err) {
      setMessages((prev) => [
        ...prev,
        {
          role: "assistant",
          content:
            "I'm sorry, I had trouble processing your request right now. Please try again in a moment, or consult a healthcare professional if your symptoms are concerning.",
        },
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-blue-50/30">
      {/* Header */}
      <header className="sticky top-0 z-20 bg-white/80 backdrop-blur-lg border-b border-slate-200">
        <div className="max-w-3xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-500 to-teal-500 flex items-center justify-center shadow-lg shadow-blue-500/20">
              <Stethoscope className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="text-lg font-semibold text-slate-900">BackPain Assistant</h1>
              <p className="text-xs text-slate-500">Educational symptom analysis</p>
            </div>
          </div>
          <a href="/conditions" className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-slate-100 hover:bg-slate-200 border border-slate-200 text-slate-600 hover:text-slate-900 text-xs font-medium transition-all">
            <Database className="w-3.5 h-3.5" />
            Manage Database
          </a>
          <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-emerald-50 border border-emerald-200">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            <span className="text-xs font-medium text-emerald-700">Online</span>
          </div>
        </div>
      </header>

      {/* Chat area */}
      <div ref={scrollRef} className="max-w-3xl mx-auto px-4 py-6 pb-40 min-h-[calc(100vh-80px)] overflow-y-auto">
        <div className="space-y-4">
          {messages.map((msg, idx) => (
            <MessageBubble key={idx} message={msg} />
          ))}
          {isLoading && (
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-blue-500 to-teal-500 flex items-center justify-center flex-shrink-0">
                <Bot className="w-4 h-4 text-white" />
              </div>
              <div className="bg-white border border-slate-200 rounded-2xl rounded-tl-sm px-4 py-3 shadow-sm">
                <div className="flex gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-slate-300 animate-bounce" style={{ animationDelay: "0ms" }} />
                  <span className="w-2 h-2 rounded-full bg-slate-300 animate-bounce" style={{ animationDelay: "150ms" }} />
                  <span className="w-2 h-2 rounded-full bg-slate-300 animate-bounce" style={{ animationDelay: "300ms" }} />
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Suggested prompts */}
        {messages.length <= 1 && !isLoading && (
          <div className="mt-8">
            <p className="text-sm font-medium text-slate-500 mb-3 flex items-center gap-1.5">
              <Activity className="w-4 h-4" />
              Try describing one of these:
            </p>
            <div className="grid gap-2">
              {SUGGESTED_PROMPTS.map((prompt, idx) => (
                <button
                  key={idx}
                  onClick={() => handleSend(prompt)}
                  className="text-left text-sm text-slate-700 bg-white border border-slate-200 rounded-xl px-4 py-3 hover:border-blue-300 hover:bg-blue-50/50 transition-all duration-200 hover:shadow-sm"
                >
                  {prompt}
                </button>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Input bar */}
      <div className="fixed bottom-0 left-0 right-0 z-20 bg-white/80 backdrop-blur-lg border-t border-slate-200">
        <div className="max-w-3xl mx-auto px-4 py-3">
          <div className="flex items-end gap-2">
            <textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault();
                  handleSend();
                }
              }}
              placeholder="Describe your lower back pain symptoms..."
              rows={1}
              className="flex-1 resize-none bg-slate-50 border border-slate-200 rounded-2xl px-4 py-3 text-sm text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-400/50 focus:border-blue-300 transition-all max-h-32"
              style={{ minHeight: "48px" }}
            />
            <Button
              onClick={() => handleSend()}
              disabled={!input.trim() || isLoading}
              className="w-12 h-12 rounded-2xl bg-gradient-to-br from-blue-500 to-teal-500 hover:from-blue-600 hover:to-teal-600 shadow-lg shadow-blue-500/20 p-0 flex-shrink-0"
            >
              <Send className="w-5 h-5 text-white" />
            </Button>
          </div>
          <p className="text-[11px] text-slate-400 mt-2 flex items-center gap-1 justify-center">
            <ShieldAlert className="w-3 h-3" />
            For educational purposes only — not a substitute for professional medical advice
          </p>
        </div>
      </div>
    </div>
  );
}