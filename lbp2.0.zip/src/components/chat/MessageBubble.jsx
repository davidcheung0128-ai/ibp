import React from "react";
import ReactMarkdown from "react-markdown";
import { Bot, User, Stethoscope, AlertTriangle, CheckCircle } from "lucide-react";

const urgencyStyles = {
  high: { bg: "bg-red-50", border: "border-red-200", text: "text-red-700", icon: AlertTriangle, label: "See a doctor soon" },
  moderate: { bg: "bg-amber-50", border: "border-amber-200", text: "text-amber-700", icon: Stethoscope, label: "Consider seeing a doctor" },
  low: { bg: "bg-emerald-50", border: "border-emerald-200", text: "text-emerald-700", icon: CheckCircle, label: "Self-care may be sufficient" },
};

export default function MessageBubble({ message }) {
  const isUser = message.role === "user";
  const urgency = message.urgency ? urgencyStyles[message.urgency] : null;
  const UrgencyIcon = urgency?.icon;

  return (
    <div className={`flex items-start gap-3 ${isUser ? "flex-row-reverse" : ""}`}>
      {/* Avatar */}
      <div
        className={`w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 ${
          isUser
            ? "bg-slate-700"
            : "bg-gradient-to-br from-blue-500 to-teal-500"
        }`}
      >
        {isUser ? (
          <User className="w-4 h-4 text-white" />
        ) : (
          <Bot className="w-4 h-4 text-white" />
        )}
      </div>

      {/* Message content */}
      <div className={`max-w-[80%] ${isUser ? "items-end" : "items-start"} flex flex-col gap-2`}>
        <div
          className={`rounded-2xl px-4 py-3 shadow-sm ${
            isUser
              ? "bg-slate-700 text-white rounded-tr-sm"
              : "bg-white border border-slate-200 text-slate-800 rounded-tl-sm"
          }`}
        >
          {isUser ? (
            <p className="text-sm whitespace-pre-wrap">{message.content}</p>
          ) : (
            <div className="text-sm prose prose-sm prose-slate max-w-none prose-p:my-1 prose-ul:my-1 prose-li:my-0">
              <ReactMarkdown>{message.content}</ReactMarkdown>
            </div>
          )}
        </div>

        {/* Matched conditions badges */}
        {message.matchedConditions?.length > 0 && (
          <div className="flex flex-wrap gap-1.5">
            {message.matchedConditions.map((cond, idx) => (
              <span
                key={idx}
                className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-blue-50 border border-blue-200 text-xs font-medium text-blue-700"
              >
                <Stethoscope className="w-3 h-3" />
                {cond}
              </span>
            ))}
          </div>
        )}

        {/* Doctor recommendation banner */}
        {urgency && (
          <div className={`flex items-center gap-2 px-3 py-2 rounded-xl ${urgency.bg} border ${urgency.border}`}>
            <UrgencyIcon className={`w-4 h-4 ${urgency.text}`} />
            <span className={`text-xs font-semibold ${urgency.text}`}>{urgency.label}</span>
          </div>
        )}
      </div>
    </div>
  );
}