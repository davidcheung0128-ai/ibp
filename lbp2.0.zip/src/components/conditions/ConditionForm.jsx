import React, { useState } from "react";
import { Save, X, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";

const emptyCondition = {
  name: "",
  description: "",
  symptoms: [],
  common_causes: [],
  severity: "moderate",
  self_care: [],
  see_doctor: false,
  doctor_reason: "",
};

export default function ConditionForm({ initial, onSave }) {
  const [form, setForm] = useState(
    initial
      ? {
          ...emptyCondition,
          ...initial,
          symptoms: initial.symptoms || [],
          common_causes: initial.common_causes || [],
          self_care: initial.self_care || [],
        }
      : emptyCondition
  );
  const [newSymptom, setNewSymptom] = useState("");
  const [newCause, setNewCause] = useState("");
  const [newSelfCare, setNewSelfCare] = useState("");
  const [saving, setSaving] = useState(false);

  const update = (field, value) => setForm((prev) => ({ ...prev, [field]: value }));

  const addItem = (field, value, setter) => {
    if (!value.trim()) return;
    update(field, [...form[field], value.trim()]);
    setter("");
  };

  const removeItem = (field, idx) => {
    update(field, form[field].filter((_, i) => i !== idx));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!form.name || !form.description) return;
    setSaving(true);
    onSave(form);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-5">
      <Card className="p-5 space-y-4">
        <div>
          <Label htmlFor="name">Condition Name *</Label>
          <Input id="name" value={form.name} onChange={(e) => update("name", e.target.value)} placeholder="e.g. Herniated Disc" required />
        </div>
        <div>
          <Label htmlFor="description">Description *</Label>
          <Textarea id="description" value={form.description} onChange={(e) => update("description", e.target.value)} placeholder="Describe what this condition is..." rows={3} required />
        </div>
        <div>
          <Label>Severity</Label>
          <div className="flex gap-2 mt-1.5">
            {["mild", "moderate", "severe"].map((s) => (
              <button
                key={s}
                type="button"
                onClick={() => update("severity", s)}
                className={`px-4 py-2 rounded-lg text-sm font-medium border transition-all capitalize ${
                  form.severity === s
                    ? s === "mild"
                      ? "bg-emerald-500 text-white border-emerald-500"
                      : s === "moderate"
                      ? "bg-amber-500 text-white border-amber-500"
                      : "bg-red-500 text-white border-red-500"
                    : "bg-white text-slate-600 border-slate-200 hover:border-slate-300"
                }`}
              >
                {s}
              </button>
            ))}
          </div>
        </div>
      </Card>

      <Card className="p-5 space-y-3">
        <div>
          <Label className="mb-1.5 block">Symptoms</Label>
          <div className="flex gap-2 mb-2">
            <Input
              value={newSymptom}
              onChange={(e) => setNewSymptom(e.target.value)}
              onKeyDown={(e) => { if (e.key === "Enter") { e.preventDefault(); addItem("symptoms", newSymptom, setNewSymptom); } }}
              placeholder="Type a symptom and press Enter"
            />
            <Button type="button" variant="outline" onClick={() => addItem("symptoms", newSymptom, setNewSymptom)}>
              <Plus className="w-4 h-4" />
            </Button>
          </div>
          <div className="flex flex-wrap gap-1.5">
            {form.symptoms.map((s, idx) => (
              <span key={idx} className="inline-flex items-center gap-1 text-sm bg-slate-100 text-slate-700 px-2.5 py-1 rounded-md">
                {s}
                <button type="button" onClick={() => removeItem("symptoms", idx)} className="text-slate-400 hover:text-red-500">
                  <X className="w-3 h-3" />
                </button>
              </span>
            ))}
          </div>
        </div>
      </Card>

      <Card className="p-5 space-y-3">
        <div>
          <Label className="mb-1.5 block">Common Causes</Label>
          <div className="flex gap-2 mb-2">
            <Input
              value={newCause}
              onChange={(e) => setNewCause(e.target.value)}
              onKeyDown={(e) => { if (e.key === "Enter") { e.preventDefault(); addItem("common_causes", newCause, setNewCause); } }}
              placeholder="Type a cause and press Enter"
            />
            <Button type="button" variant="outline" onClick={() => addItem("common_causes", newCause, setNewCause)}>
              <Plus className="w-4 h-4" />
            </Button>
          </div>
          <div className="flex flex-wrap gap-1.5">
            {form.common_causes.map((c, idx) => (
              <span key={idx} className="inline-flex items-center gap-1 text-sm bg-slate-100 text-slate-700 px-2.5 py-1 rounded-md">
                {c}
                <button type="button" onClick={() => removeItem("common_causes", idx)} className="text-slate-400 hover:text-red-500">
                  <X className="w-3 h-3" />
                </button>
              </span>
            ))}
          </div>
        </div>
      </Card>

      <Card className="p-5 space-y-3">
        <div>
          <Label className="mb-1.5 block">Self-Care Recommendations</Label>
          <div className="flex gap-2 mb-2">
            <Input
              value={newSelfCare}
              onChange={(e) => setNewSelfCare(e.target.value)}
              onKeyDown={(e) => { if (e.key === "Enter") { e.preventDefault(); addItem("self_care", newSelfCare, setNewSelfCare); } }}
              placeholder="Type a self-care tip and press Enter"
            />
            <Button type="button" variant="outline" onClick={() => addItem("self_care", newSelfCare, setNewSelfCare)}>
              <Plus className="w-4 h-4" />
            </Button>
          </div>
          <div className="flex flex-wrap gap-1.5">
            {form.self_care.map((s, idx) => (
              <span key={idx} className="inline-flex items-center gap-1 text-sm bg-emerald-50 text-emerald-700 px-2.5 py-1 rounded-md">
                {s}
                <button type="button" onClick={() => removeItem("self_care", idx)} className="text-emerald-400 hover:text-red-500">
                  <X className="w-3 h-3" />
                </button>
              </span>
            ))}
          </div>
        </div>
      </Card>

      <Card className="p-5 space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <Label>Recommend Seeing a Doctor?</Label>
            <p className="text-xs text-slate-500 mt-0.5">Mark if patients with this condition should seek professional care</p>
          </div>
          <button
            type="button"
            onClick={() => update("see_doctor", !form.see_doctor)}
            className={`relative w-12 h-6 rounded-full transition-colors ${form.see_doctor ? "bg-blue-500" : "bg-slate-200"}`}
          >
            <span className={`absolute top-0.5 left-0.5 w-5 h-5 rounded-full bg-white transition-transform ${form.see_doctor ? "translate-x-6" : ""}`} />
          </button>
        </div>
        {form.see_doctor && (
          <div>
            <Label htmlFor="doctor_reason">Why See a Doctor</Label>
            <Textarea id="doctor_reason" value={form.doctor_reason} onChange={(e) => update("doctor_reason", e.target.value)} placeholder="Explain why professional care is recommended..." rows={2} />
          </div>
        )}
      </Card>

      <div className="flex gap-2 sticky bottom-4">
        <Button type="submit" disabled={saving || !form.name || !form.description} className="flex-1 bg-gradient-to-br from-blue-500 to-teal-500 hover:from-blue-600 hover:to-teal-600">
          <Save className="w-4 h-4 mr-1" /> {saving ? "Saving..." : "Save Condition"}
        </Button>
      </div>
    </form>
  );
}